const GITHUB_REPO = "lakhanahir9499/movie"
const FILE_PATH = "movies.json"
const GITHUB_API_BASE = "https://api.github.com"

interface Movie {
  title: string
  caption: string
  poster: string
  downloadLink: string
}

export async function getMoviesFromGitHub(): Promise<Movie[]> {
  try {
    const headers: HeadersInit = {
      Accept: "application/vnd.github.v3+json",
      "User-Agent": "MovieHub-App",
    }

    // Use the server-side PAT
    if (process.env.GITHUB_PAT) {
      headers.Authorization = `token ${process.env.GITHUB_PAT}`
    }

    const response = await fetch(`${GITHUB_API_BASE}/repos/${GITHUB_REPO}/contents/${FILE_PATH}`, {
      headers,
      cache: "no-store", // No caching - always fetch fresh data
    })

    if (!response.ok) {
      console.error("Failed to fetch from GitHub:", response.status)
      return []
    }

    const data = await response.json()
    const content = Buffer.from(data.content, "base64").toString("utf-8")
    const movies = JSON.parse(content)

    return movies
  } catch (error) {
    console.error("Error fetching movies from GitHub:", error)
    return []
  }
}
