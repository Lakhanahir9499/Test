import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Download } from "lucide-react"
import Image from "next/image"

interface Movie {
  title: string
  caption: string
  poster: string
  downloadLink: string
}

interface MovieCardProps {
  movie: Movie
}

export function MovieCard({ movie }: MovieCardProps) {
  return (
    <Card className="group overflow-hidden border-0 shadow-sm hover:shadow-lg transition-all duration-300 bg-white">
      <div className="relative aspect-[2/3] overflow-hidden bg-gray-100">
        <Image
          src={movie.poster || "/placeholder.svg?height=300&width=200"}
          alt={movie.title}
          fill
          className="object-cover group-hover:scale-105 transition-transform duration-300"
          sizes="(max-width: 640px) 50vw, (max-width: 768px) 33vw, (max-width: 1024px) 25vw, (max-width: 1280px) 20vw, 16vw"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

        {/* Download button overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white shadow-lg" asChild>
            <a href={movie.downloadLink} target="_blank" rel="noopener noreferrer">
              <Download className="w-4 h-4 mr-1" />
              Download
            </a>
          </Button>
        </div>
      </div>

      <CardContent className="p-3">
        <h3 className="font-semibold text-sm text-gray-900 mb-1 line-clamp-2 leading-tight">{movie.title}</h3>
        <p className="text-xs text-gray-600 line-clamp-2 mb-2 leading-relaxed">{movie.caption}</p>

        <Button
          size="sm"
          className="w-full h-8 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white text-xs"
          asChild
        >
          <a href={movie.downloadLink} target="_blank" rel="noopener noreferrer">
            <Download className="w-3 h-3 mr-1" />
            Download
          </a>
        </Button>
      </CardContent>
    </Card>
  )
}
