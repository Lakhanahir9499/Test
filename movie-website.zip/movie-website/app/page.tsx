"use client"

import { useState, useEffect } from "react"
import { MovieCard } from "@/components/movie-card"
import { Search, Filter } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

interface Movie {
  title: string
  caption: string
  poster: string
  downloadLink: string
}

export default function HomePage() {
  const [movies, setMovies] = useState<Movie[]>([])
  const [filteredMovies, setFilteredMovies] = useState<Movie[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchMovies()
  }, [])

  useEffect(() => {
    if (searchQuery.trim() === "") {
      setFilteredMovies(movies)
    } else {
      const filtered = movies.filter(
        (movie) =>
          movie.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          movie.caption.toLowerCase().includes(searchQuery.toLowerCase()),
      )
      setFilteredMovies(filtered)
    }
  }, [searchQuery, movies])

  const fetchMovies = async () => {
    try {
      setLoading(true)
      const response = await fetch(`/api/movies?t=${Date.now()}`, {
        cache: "no-store",
      })
      const data = await response.json()
      setMovies(data)
      setFilteredMovies(data)
    } catch (error) {
      console.error("Failed to fetch movies:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                <span className="text-white font-bold text-lg">🎬</span>
              </div>
              <h1 className="text-2xl font-bold text-gray-900">MovieHub</h1>
            </div>

            <div className="flex-1 max-w-md">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search movies..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-gray-50 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
            </div>

            <Button onClick={fetchMovies} variant="outline" size="sm" className="hidden sm:flex bg-transparent">
              <Filter className="w-4 h-4 mr-2" />
              Refresh
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-700 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">Latest Movies Collection</h2>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto">
            Discover and download your favorite movies from our curated collection
          </p>
          <div className="mt-8 flex justify-center gap-4 text-sm text-blue-200">
            <span>📱 Mobile Friendly</span>
            <span>⚡ Fast Loading</span>
            <span>🔄 Always Updated</span>
          </div>
        </div>
      </section>

      {/* Movies Grid */}
      <section className="py-8 flex-1">
        <div className="container mx-auto px-4">
          {/* Search Results Info */}
          <div className="mb-6 flex items-center justify-between">
            <div className="text-gray-600">
              {searchQuery ? (
                <span>
                  Found {filteredMovies.length} movie{filteredMovies.length !== 1 ? "s" : ""} for "{searchQuery}"
                </span>
              ) : (
                <span>{movies.length} movies available</span>
              )}
            </div>
          </div>

          {loading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {[...Array(12)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-gray-200 aspect-[2/3] rounded-lg mb-3"></div>
                  <div className="bg-gray-200 h-4 rounded mb-2"></div>
                  <div className="bg-gray-200 h-3 rounded w-3/4"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {filteredMovies.map((movie, index) => (
                <MovieCard key={index} movie={movie} />
              ))}
            </div>
          )}

          {!loading && filteredMovies.length === 0 && (
            <div className="text-center py-20">
              <div className="text-6xl mb-4">🎬</div>
              <h3 className="text-xl font-semibold text-gray-700 mb-2">
                {searchQuery ? "No movies found" : "No movies available"}
              </h3>
              <p className="text-gray-500">
                {searchQuery ? "Try searching with different keywords" : "Check back later for new movies"}
              </p>
              {searchQuery && (
                <Button onClick={() => setSearchQuery("")} variant="outline" className="mt-4">
                  Clear Search
                </Button>
              )}
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-8 mt-auto">
        <div className="container mx-auto px-4">
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold">🎬</span>
              </div>
              <span className="font-semibold text-gray-900">MovieHub</span>
            </div>
            <div className="space-y-2 text-sm text-gray-600">
              <p>© 2024 MovieHub. All rights reserved.</p>
              <p>
                Website developed by{" "}
                <a
                  href="https://modverse.online"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:text-blue-700 font-medium transition-colors"
                >
                  ModVerse.online
                </a>
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
