import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'modverse team',
  description: 'Created with modverse',
  generator: 'modverse.online',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
