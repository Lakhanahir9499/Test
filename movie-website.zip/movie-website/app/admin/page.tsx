"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Trash2, Edit, Plus, Save, X, RefreshCw, Eye, EyeOff, Menu } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import Image from "next/image"

interface Movie {
  title: string
  caption: string
  poster: string
  downloadLink: string
}

const ADMIN_KEY = "Demo123"

export default function AdminPage() {
  const [movies, setMovies] = useState<Movie[]>([])
  const [adminKey, setAdminKey] = useState("")
  const [showKey, setShowKey] = useState(false)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [editingIndex, setEditingIndex] = useState<number | null>(null)
  const [newMovie, setNewMovie] = useState<Movie>({
    title: "",
    caption: "",
    poster: "",
    downloadLink: "",
  })
  const [showAddForm, setShowAddForm] = useState(false)
  const [loading, setLoading] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    if (isAuthenticated) {
      fetchMovies()
    }
  }, [isAuthenticated])

  const fetchMovies = async () => {
    try {
      setLoading(true)
      const response = await fetch(`/api/movies?t=${Date.now()}`, {
        cache: "no-store",
        headers: {
          "Cache-Control": "no-cache",
        },
      })
      const data = await response.json()
      setMovies(data)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch movies",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const authenticate = async () => {
    if (!adminKey) {
      toast({
        title: "Error",
        description: "Please enter admin key",
        variant: "destructive",
      })
      return
    }

    if (adminKey !== ADMIN_KEY) {
      toast({
        title: "Error",
        description: "Invalid admin key",
        variant: "destructive",
      })
      return
    }

    sessionStorage.setItem("admin_key", adminKey)
    setIsAuthenticated(true)
    toast({
      title: "Success",
      description: "Welcome to admin panel!",
    })
  }

  const makeAuthenticatedRequest = async (url: string, options: RequestInit = {}) => {
    return fetch(url, {
      ...options,
      headers: {
        ...options.headers,
        "X-Admin-Key": sessionStorage.getItem("admin_key") || "",
      },
    })
  }

  const addMovie = async () => {
    if (!newMovie.title || !newMovie.caption) {
      toast({
        title: "Error",
        description: "Title and caption are required",
        variant: "destructive",
      })
      return
    }

    try {
      setLoading(true)
      const response = await makeAuthenticatedRequest("/api/movies", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newMovie),
      })

      const result = await response.json()

      if (response.ok) {
        setNewMovie({ title: "", caption: "", poster: "", downloadLink: "" })
        setShowAddForm(false)
        fetchMovies()
        toast({
          title: "Success",
          description: "Movie added successfully!",
        })
      } else {
        throw new Error(result.details || result.error || "Failed to add movie")
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to add movie",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const updateMovie = async (index: number, updatedMovie: Movie) => {
    try {
      setLoading(true)
      const response = await makeAuthenticatedRequest("/api/movies", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ index, movie: updatedMovie }),
      })

      const result = await response.json()

      if (response.ok) {
        setEditingIndex(null)
        fetchMovies()
        toast({
          title: "Success",
          description: "Movie updated successfully!",
        })
      } else {
        throw new Error(result.details || result.error || "Failed to update movie")
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update movie",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const deleteMovie = async (index: number) => {
    if (!confirm("Are you sure you want to delete this movie?")) return

    try {
      setLoading(true)
      const response = await makeAuthenticatedRequest("/api/movies", {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ index }),
      })

      const result = await response.json()

      if (response.ok) {
        fetchMovies()
        toast({
          title: "Success",
          description: "Movie deleted successfully!",
        })
      } else {
        throw new Error(result.details || result.error || "Failed to delete movie")
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete movie",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md shadow-xl border-0">
          <CardHeader className="text-center pb-4">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <span className="text-white text-2xl">🔐</span>
            </div>
            <CardTitle className="text-2xl font-bold text-gray-900">Admin Panel</CardTitle>
            <p className="text-gray-600">Enter your admin key to continue</p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="adminKey" className="text-gray-700 font-medium">
                Admin Key
              </Label>
              <div className="relative mt-1">
                <Input
                  id="adminKey"
                  type={showKey ? "text" : "password"}
                  value={adminKey}
                  onChange={(e) => setAdminKey(e.target.value)}
                  placeholder="Enter admin key"
                  className="pr-10 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  onKeyPress={(e) => e.key === "Enter" && authenticate()}
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                  onClick={() => setShowKey(!showKey)}
                >
                  {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </Button>
              </div>
            </div>
            <Button
              onClick={authenticate}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              disabled={loading}
            >
              {loading ? "Authenticating..." : "Access Admin Panel"}
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex flex-col">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-gray-200 sticky top-0 z-50">
        <div className="px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                <span className="text-white font-bold">🎬</span>
              </div>
              <div className="hidden sm:block">
                <h1 className="text-xl font-bold text-gray-900">Admin Panel</h1>
                <p className="text-sm text-gray-600">Manage your movie collection</p>
              </div>
              <div className="sm:hidden">
                <h1 className="text-lg font-bold text-gray-900">Admin</h1>
              </div>
            </div>

            {/* Desktop Actions */}
            <div className="hidden sm:flex items-center gap-2">
              <Badge variant="secondary">{movies.length} Movies</Badge>
              <Button onClick={fetchMovies} variant="outline" size="sm" disabled={loading}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
              <Button
                onClick={() => setShowAddForm(true)}
                size="sm"
                className="bg-green-600 hover:bg-green-700"
                disabled={loading}
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Movie
              </Button>
              <Button
                onClick={() => {
                  setIsAuthenticated(false)
                  sessionStorage.removeItem("admin_key")
                }}
                variant="outline"
                size="sm"
              >
                Logout
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <div className="sm:hidden">
              <Button variant="outline" size="sm" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                <Menu className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="sm:hidden mt-4 pt-4 border-t border-gray-200 space-y-2">
              <div className="flex items-center justify-between mb-3">
                <Badge variant="secondary">{movies.length} Movies</Badge>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  onClick={fetchMovies}
                  variant="outline"
                  size="sm"
                  disabled={loading}
                  className="w-full bg-transparent"
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Refresh
                </Button>
                <Button
                  onClick={() => {
                    setShowAddForm(true)
                    setMobileMenuOpen(false)
                  }}
                  size="sm"
                  className="bg-green-600 hover:bg-green-700 w-full"
                  disabled={loading}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add
                </Button>
              </div>
              <Button
                onClick={() => {
                  setIsAuthenticated(false)
                  sessionStorage.removeItem("admin_key")
                }}
                variant="outline"
                size="sm"
                className="w-full"
              >
                Logout
              </Button>
            </div>
          )}
        </div>
      </header>

      <div className="flex-1 px-4 py-6 max-w-full overflow-hidden">
        {/* Add Movie Form */}
        {showAddForm && (
          <Card className="mb-6 shadow-lg border-0">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Plus className="w-5 h-5" />
                Add New Movie
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 gap-4">
                <div>
                  <Label className="text-gray-700 font-medium text-sm">Title *</Label>
                  <Input
                    value={newMovie.title}
                    onChange={(e) => setNewMovie({ ...newMovie, title: e.target.value })}
                    placeholder="Enter movie title"
                    className="border-gray-200 focus:border-blue-500 focus:ring-blue-500 text-sm"
                  />
                </div>
                <div>
                  <Label className="text-gray-700 font-medium text-sm">Poster URL</Label>
                  <Input
                    value={newMovie.poster}
                    onChange={(e) => setNewMovie({ ...newMovie, poster: e.target.value })}
                    placeholder="Enter poster image URL"
                    className="border-gray-200 focus:border-blue-500 focus:ring-blue-500 text-sm"
                  />
                </div>
              </div>

              <div>
                <Label className="text-gray-700 font-medium text-sm">Caption *</Label>
                <Textarea
                  value={newMovie.caption}
                  onChange={(e) => setNewMovie({ ...newMovie, caption: e.target.value })}
                  placeholder="Enter movie description"
                  className="border-gray-200 focus:border-blue-500 focus:ring-blue-500 text-sm"
                  rows={3}
                />
              </div>

              <div>
                <Label className="text-gray-700 font-medium text-sm">Download Link</Label>
                <Input
                  value={newMovie.downloadLink}
                  onChange={(e) => setNewMovie({ ...newMovie, downloadLink: e.target.value })}
                  placeholder="Enter download URL"
                  className="border-gray-200 focus:border-blue-500 focus:ring-blue-500 text-sm"
                />
              </div>

              <div className="flex flex-col sm:flex-row gap-2 pt-2">
                <Button onClick={addMovie} className="bg-green-600 hover:bg-green-700 flex-1" disabled={loading}>
                  <Save className="w-4 h-4 mr-2" />
                  {loading ? "Saving..." : "Save Movie"}
                </Button>
                <Button onClick={() => setShowAddForm(false)} variant="outline" disabled={loading} className="flex-1">
                  <X className="w-4 h-4 mr-2" />
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Movies List */}
        <div className="space-y-4">
          {movies.map((movie, index) => (
            <Card key={index} className="shadow-lg border-0 overflow-hidden">
              <CardContent className="p-0">
                {editingIndex === index ? (
                  <EditMovieForm
                    movie={movie}
                    onSave={(updatedMovie) => updateMovie(index, updatedMovie)}
                    onCancel={() => setEditingIndex(null)}
                    loading={loading}
                  />
                ) : (
                  <div className="flex flex-col">
                    {/* Movie Poster - Full width on mobile */}
                    <div className="w-full h-48 sm:hidden relative bg-gray-100">
                      <Image
                        src={movie.poster || "/placeholder.svg?height=192&width=full"}
                        alt={movie.title}
                        fill
                        className="object-cover"
                        sizes="100vw"
                      />
                    </div>

                    <div className="flex">
                      {/* Desktop Poster */}
                      <div className="hidden sm:block w-32 h-32 relative bg-gray-100 flex-shrink-0">
                        <Image
                          src={movie.poster || "/placeholder.svg?height=128&width=128"}
                          alt={movie.title}
                          fill
                          className="object-cover"
                          sizes="128px"
                        />
                      </div>

                      {/* Movie Info */}
                      <div className="flex-1 p-4 min-w-0">
                        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-4">
                          <div className="flex-1 min-w-0">
                            <h3 className="font-bold text-lg text-gray-900 mb-2 break-words">{movie.title}</h3>
                            <p className="text-gray-600 mb-3 text-sm break-words">{movie.caption}</p>
                            <div className="space-y-1 text-xs">
                              <p className="text-gray-500 break-all">
                                <span className="font-medium">Poster:</span>{" "}
                                {movie.poster ? (
                                  <span className="text-green-600">✓ Set</span>
                                ) : (
                                  <span className="text-gray-400">Not set</span>
                                )}
                              </p>
                              <p className="text-gray-500 break-all">
                                <span className="font-medium">Download:</span>{" "}
                                {movie.downloadLink ? (
                                  <span className="text-green-600">✓ Set</span>
                                ) : (
                                  <span className="text-gray-400">Not set</span>
                                )}
                              </p>
                            </div>
                          </div>

                          {/* Action Buttons */}
                          <div className="flex gap-2 flex-shrink-0">
                            <Button
                              size="sm"
                              onClick={() => setEditingIndex(index)}
                              className="bg-blue-600 hover:bg-blue-700"
                              disabled={loading}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              onClick={() => deleteMovie(index)}
                              className="bg-red-600 hover:bg-red-700"
                              disabled={loading}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {movies.length === 0 && !loading && (
          <div className="text-center py-20">
            <div className="text-6xl mb-4">🎬</div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No movies yet</h3>
            <p className="text-gray-500 mb-6">Add your first movie to get started!</p>
            <Button onClick={() => setShowAddForm(true)} className="bg-green-600 hover:bg-green-700">
              <Plus className="w-4 h-4 mr-2" />
              Add First Movie
            </Button>
          </div>
        )}

        {loading && (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    <div className="w-24 h-24 bg-gray-200 rounded flex-shrink-0"></div>
                    <div className="flex-1 space-y-2 min-w-0">
                      <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                      <div className="h-3 bg-gray-200 rounded w-full"></div>
                      <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-6 mt-auto">
        <div className="px-4">
          <div className="text-center space-y-3">
            <div className="flex items-center justify-center gap-2">
              <div className="w-6 h-6 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">🎬</span>
              </div>
              <span className="font-semibold text-gray-900 text-sm">MovieHub Admin</span>
            </div>
            <div className="space-y-1 text-xs text-gray-600">
              <p>© 2024 MovieHub. All rights reserved.</p>
              <p>
                Website developed by{" "}
                <a
                  href="https://modverse.online"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:text-blue-700 font-medium transition-colors"
                >
                  ModVerse.online
                </a>
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

function EditMovieForm({
  movie,
  onSave,
  onCancel,
  loading,
}: {
  movie: Movie
  onSave: (movie: Movie) => void
  onCancel: () => void
  loading: boolean
}) {
  const [editedMovie, setEditedMovie] = useState(movie)

  return (
    <div className="p-4 bg-gray-50">
      <h4 className="font-semibold text-gray-900 mb-4 flex items-center gap-2 text-sm">
        <Edit className="w-4 h-4" />
        Edit Movie
      </h4>

      <div className="space-y-4">
        <div className="grid grid-cols-1 gap-4">
          <div>
            <Label className="text-gray-700 font-medium text-sm">Title</Label>
            <Input
              value={editedMovie.title}
              onChange={(e) => setEditedMovie({ ...editedMovie, title: e.target.value })}
              className="border-gray-200 focus:border-blue-500 focus:ring-blue-500 text-sm"
            />
          </div>
          <div>
            <Label className="text-gray-700 font-medium text-sm">Poster URL</Label>
            <Input
              value={editedMovie.poster}
              onChange={(e) => setEditedMovie({ ...editedMovie, poster: e.target.value })}
              className="border-gray-200 focus:border-blue-500 focus:ring-blue-500 text-sm"
            />
          </div>
        </div>

        <div>
          <Label className="text-gray-700 font-medium text-sm">Caption</Label>
          <Textarea
            value={editedMovie.caption}
            onChange={(e) => setEditedMovie({ ...editedMovie, caption: e.target.value })}
            className="border-gray-200 focus:border-blue-500 focus:ring-blue-500 text-sm"
            rows={3}
          />
        </div>

        <div>
          <Label className="text-gray-700 font-medium text-sm">Download Link</Label>
          <Input
            value={editedMovie.downloadLink}
            onChange={(e) => setEditedMovie({ ...editedMovie, downloadLink: e.target.value })}
            className="border-gray-200 focus:border-blue-500 focus:ring-blue-500 text-sm"
          />
        </div>

        <div className="flex flex-col sm:flex-row gap-2 pt-2">
          <Button
            onClick={() => onSave(editedMovie)}
            className="bg-green-600 hover:bg-green-700 flex-1"
            disabled={loading}
          >
            <Save className="w-4 h-4 mr-2" />
            {loading ? "Saving..." : "Save Changes"}
          </Button>
          <Button onClick={onCancel} variant="outline" disabled={loading} className="flex-1 bg-transparent">
            <X className="w-4 h-4 mr-2" />
            Cancel
          </Button>
        </div>
      </div>
    </div>
  )
}
