import { type NextRequest, NextResponse } from "next/server"

const GITHUB_REPO = "YOUR GITHUB USERNAME/REPO NAME"
const FILE_PATH = "movies.json"
const DEFAULT_BRANCH = "main"
const API_BASE = "https://api.github.com"
const GITHUB_PAT = "YOUR GITHUB PAT" // Your PAT stored server-side
const ADMIN_KEY = "Demo123" // Admin access key

interface Movie {
  title: string
  caption: string
  poster: string
  downloadLink: string
}

/* ---------- Helper utilities ---------- */
async function githubHeaders(): Promise<HeadersInit> {
  return {
    Accept: "application/vnd.github.v3+json",
    "User-Agent": "MovieHub-App",
    Authorization: `token ${GITHUB_PAT}`,
  }
}

type FileResult = { exists: false } | { exists: true; sha: string; movies: Movie[] }

async function fetchMovieFile(): Promise<FileResult> {
  try {
    const res = await fetch(`${API_BASE}/repos/${GITHUB_REPO}/contents/${FILE_PATH}`, {
      headers: await githubHeaders(),
      cache: "no-store", // No caching
    })

    if (res.status === 404) return { exists: false }

    if (!res.ok) {
      console.error(`GitHub GET failed: ${res.status} - ${await res.text()}`)
      throw new Error(`GitHub GET failed: ${res.status}`)
    }

    const json = await res.json()
    const content = Buffer.from(json.content, "base64").toString("utf8")
    const movies = JSON.parse(content) as Movie[]
    return { exists: true, sha: json.sha as string, movies }
  } catch (error) {
    console.error("Error in fetchMovieFile:", error)
    return { exists: false }
  }
}

async function pushMovieFile(movies: Movie[], message: string, sha?: string) {
  const body: Record<string, unknown> = {
    message,
    content: Buffer.from(JSON.stringify(movies, null, 2)).toString("base64"),
  }

  if (sha) {
    body.sha = sha
  }

  console.log(`Pushing to GitHub: ${message}`, { hasSha: !!sha })

  const res = await fetch(`${API_BASE}/repos/${GITHUB_REPO}/contents/${FILE_PATH}`, {
    method: "PUT",
    headers: {
      ...(await githubHeaders()),
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  })

  if (!res.ok) {
    const errorText = await res.text()
    console.error(`GitHub PUT failed: ${res.status} - ${errorText}`)
    throw new Error(`GitHub PUT failed: ${res.status} - ${errorText}`)
  }

  return await res.json()
}

function verifyAdminKey(req: NextRequest): boolean {
  const adminKey = req.headers.get("X-Admin-Key")
  return adminKey === ADMIN_KEY
}

/* ---------- ROUTE HANDLERS ---------- */

export async function GET() {
  try {
    const file = await fetchMovieFile()
    return NextResponse.json(file.exists ? file.movies : [], {
      headers: {
        "Cache-Control": "no-store, no-cache, must-revalidate, proxy-revalidate",
        Pragma: "no-cache",
        Expires: "0",
      },
    })
  } catch (e) {
    console.error("GET /movies:", e)
    return NextResponse.json([], { status: 200 })
  }
}

export async function POST(req: NextRequest) {
  try {
    if (!verifyAdminKey(req)) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const newMovie: Movie = await req.json()

    // Validate movie data
    if (!newMovie.title || !newMovie.caption) {
      return NextResponse.json({ error: "Title and caption are required" }, { status: 400 })
    }

    const file = await fetchMovieFile()
    const movies = file.exists ? [...file.movies, newMovie] : [newMovie]

    await pushMovieFile(movies, `Add movie: ${newMovie.title}`, file.exists ? file.sha : undefined)

    return NextResponse.json({ success: true })
  } catch (e) {
    console.error("POST /movies:", e)
    return NextResponse.json(
      {
        error: "Failed to add movie",
        details: e instanceof Error ? e.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function PUT(req: NextRequest) {
  try {
    if (!verifyAdminKey(req)) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { index, movie }: { index: number; movie: Movie } = await req.json()
    const file = await fetchMovieFile()
    if (!file.exists) throw new Error("Movie file not found")

    const movies = [...file.movies]
    if (index < 0 || index >= movies.length) {
      throw new Error("Invalid movie index")
    }

    movies[index] = movie

    await pushMovieFile(movies, `Update movie: ${movie.title}`, file.sha)
    return NextResponse.json({ success: true })
  } catch (e) {
    console.error("PUT /movies:", e)
    return NextResponse.json(
      {
        error: "Failed to update movie",
        details: e instanceof Error ? e.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function DELETE(req: NextRequest) {
  try {
    if (!verifyAdminKey(req)) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { index }: { index: number } = await req.json()
    const file = await fetchMovieFile()
    if (!file.exists) throw new Error("Movie file not found")

    if (index < 0 || index >= file.movies.length) {
      throw new Error("Invalid movie index")
    }

    const movies = [...file.movies]
    const [removed] = movies.splice(index, 1)

    await pushMovieFile(movies, `Delete movie: ${removed.title}`, file.sha)
    return NextResponse.json({ success: true })
  } catch (e) {
    console.error("DELETE /movies:", e)
    return NextResponse.json(
      {
        error: "Failed to delete movie",
        details: e instanceof Error ? e.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
