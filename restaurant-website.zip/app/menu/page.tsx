import { MenuItemCard } from "@/components/menu-item-card"

const menuItems = {
  appetizers: [
    {
      id: "app1",
      name: "Crispy Calamari",
      description: "Lightly fried calamari served with a zesty marinara sauce.",
      price: 12.5,
      image: "/images/crispy-calamari.png",
    },
    {
      id: "app2",
      name: "Caprese Skewers",
      description: "Fresh mozzarella, cherry tomatoes, and basil drizzled with balsamic glaze.",
      price: 9.0,
      image: "/images/caprese-skewers.png",
    },
    {
      id: "app3",
      name: "Garlic Parmesan Fries",
      description: "Golden fries tossed with garlic, parmesan, and fresh parsley.",
      price: 7.5,
      image: "/images/garlic-parmesan-fries.png",
    },
  ],
  mainCourses: [
    {
      id: "main1",
      name: "Grilled Salmon",
      description: "Pan-seared salmon fillet with asparagus and lemon-dill sauce.",
      price: 24.99,
      image: "/images/grilled-salmon.png",
    },
    {
      id: "main2",
      name: "Ribeye Steak",
      description: "12oz prime ribeye, perfectly grilled, served with mashed potatoes.",
      price: 32.0,
      image: "/images/ribeye-steak.png",
    },
    {
      id: "main3",
      name: "Vegetable Lasagna",
      description: "Layers of pasta, rich tomato sauce, and seasonal vegetables, baked to perfection.",
      price: 18.75,
      image: "/images/vegetable-lasagna.png",
    },
    {
      id: "main4",
      name: "Chicken Alfredo",
      description: "Creamy fettuccine alfredo with tender grilled chicken breast.",
      price: 20.5,
      image: "/images/chicken-alfredo.png",
    },
  ],
  desserts: [
    {
      id: "des1",
      name: "New York Cheesecake",
      description: "Classic cheesecake with a berry compote.",
      price: 8.5,
      image: "/images/new-york-cheesecake.png",
    },
    {
      id: "des2",
      name: "Tiramisu",
      description: "Traditional Italian coffee-flavored dessert.",
      price: 9.0,
      image: "/images/tiramisu.png",
    },
  ],
  drinks: [
    {
      id: "drink1",
      name: "Fresh Orange Juice",
      description: "Freshly squeezed orange juice.",
      price: 4.0,
      image: "/images/fresh-orange-juice.png",
    },
    {
      id: "drink2",
      name: "Sparkling Water",
      description: "Premium sparkling mineral water.",
      price: 3.5,
      image: "/images/sparkling-water.png",
    },
    {
      id: "drink3",
      name: "House Red Wine",
      description: "A glass of our finest house red wine.",
      price: 10.0,
      image: "/images/house-red-wine.png",
    },
  ],
}

export default function MenuPage() {
  return (
    <main className="container py-12 md:py-16 lg:py-20">
      <h1 className="text-4xl md:text-5xl font-bold text-center mb-12">Our Delicious Menu</h1>

      {Object.entries(menuItems).map(([category, items]) => (
        <section key={category} className="mb-12">
          <h2 className="text-3xl md:text-4xl font-semibold capitalize mb-8 text-center md:text-left">
            {category.replace(/([A-Z])/g, " $1")}
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {items.map((item) => (
              <MenuItemCard
                key={item.id}
                name={item.name}
                description={item.description}
                price={item.price}
                image={item.image}
              />
            ))}
          </div>
        </section>
      ))}
    </main>
  )
}
