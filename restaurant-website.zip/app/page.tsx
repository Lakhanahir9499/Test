import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function HomePage() {
  return (
    <main className="flex-1">
      {/* Hero Section */}
      <section
        className="relative w-full h-[60vh] md:h-[70vh] lg:h-[80vh] flex items-center justify-center text-center bg-cover bg-center"
        style={{ backgroundImage: "url(/images/hero-background.png)" }}
      >
        <div className="absolute inset-0 bg-black/60" />
        <div className="z-10 text-white space-y-4 px-4 md:px-6">
          <h1 className="text-4xl md:text-6xl font-bold tracking-tighter">Delicious Eats</h1>
          <p className="max-w-[700px] text-lg md:text-xl mx-auto">
            Experience the finest culinary journey with our exquisite dishes and cozy ambiance.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90">
              <Link href="/menu">View Our Menu</Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="text-white border-white hover:bg-white/20">
              <Link href="/booking">Book a Table</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* About Us Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
        <div className="container grid items-center gap-6 px-4 md:px-6 lg:grid-cols-2 lg:gap-10">
          <Image
            src="/images/restaurant-interior.png"
            width={600}
            height={400}
            alt="Restaurant Interior"
            className="mx-auto aspect-video overflow-hidden rounded-xl object-cover object-center sm:w-full lg:order-last"
          />
          <div className="flex flex-col justify-center space-y-4">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight">About Delicious Eats</h2>
              <p className="max-w-[600px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                At Delicious Eats, we believe in creating memorable dining experiences. Our chefs craft each dish with
                passion, using only the freshest, locally sourced ingredients. From classic comfort food to innovative
                culinary creations, we invite you to savor every moment.
              </p>
            </div>
            <Button asChild variant="outline">
              <Link href="/booking">Learn More & Reserve</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Featured Dishes Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container space-y-12 px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Our Signature Dishes</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Discover some of our most popular and beloved dishes, crafted to perfection.
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl items-start gap-8 sm:grid-cols-2 md:gap-12 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <Image
                  src="/images/gourmet-burger.png"
                  width={300}
                  height={200}
                  alt="Dish 1"
                  className="rounded-md object-cover w-full h-48"
                />
                <CardTitle className="mt-4">Gourmet Burger</CardTitle>
                <CardDescription>Juicy patty, fresh veggies, and our secret sauce.</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg font-semibold">$18.99</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <Image
                  src="/images/seafood-pasta.png"
                  width={300}
                  height={200}
                  alt="Dish 2"
                  className="rounded-md object-cover w-full h-48"
                />
                <CardTitle className="mt-4">Seafood Pasta</CardTitle>
                <CardDescription>Fresh seafood tossed in a rich tomato sauce.</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg font-semibold">$24.50</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <Image
                  src="/images/chocolate-lava-cake.png"
                  width={300}
                  height={200}
                  alt="Dish 3"
                  className="rounded-md object-cover w-full h-48"
                />
                <CardTitle className="mt-4">Chocolate Lava Cake</CardTitle>
                <CardDescription>Warm, gooey chocolate cake with a molten center.</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg font-semibold">$9.75</p>
              </CardContent>
            </Card>
          </div>
          <div className="flex justify-center">
            <Button asChild size="lg">
              <Link href="/menu">View Full Menu</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Call to Action for Booking */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-primary text-primary-foreground">
        <div className="container grid items-center justify-center gap-4 px-4 text-center md:px-6">
          <div className="space-y-3">
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight">Ready to Dine With Us?</h2>
            <p className="mx-auto max-w-[600px] md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Make a reservation today and secure your spot for an unforgettable dining experience.
            </p>
          </div>
          <Button asChild variant="secondary" size="lg">
            <Link href="/booking">Book Your Table Now</Link>
          </Button>
        </div>
      </section>
    </main>
  )
}
