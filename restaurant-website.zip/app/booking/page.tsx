import { BookingForm } from "@/components/booking-form"

export default function BookingPage() {
  return (
    <main className="container py-12 md:py-16 lg:py-20 flex flex-col items-center">
      <h1 className="text-4xl md:text-5xl font-bold text-center mb-8">Make a Reservation</h1>
      <p className="text-lg text-muted-foreground text-center max-w-2xl mb-12">
        Planning a visit? Book your table in advance to ensure a seamless dining experience at Delicious Eats.
      </p>
      <BookingForm />
    </main>
  )
}
