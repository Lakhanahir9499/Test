"use client"

import Image from "next/image"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { toast } from "@/components/ui/use-toast"

interface MenuItemCardProps {
  name: string
  description: string
  price: number
  image: string
}

export function MenuItemCard({ name, description, price, image }: MenuItemCardProps) {
  const handleBuyClick = () => {
    console.log(`Added "${name}" to cart! Price: $${price.toFixed(2)}`)
    toast({
      title: "Item Added!",
      description: `"${name}" has been added to your order.`,
    })
  }

  return (
    <Card className="flex flex-col overflow-hidden">
      <div className="relative h-48 w-full">
        <Image src={image || "/placeholder.svg"} alt={name} fill objectFit="cover" className="rounded-t-lg" />
      </div>
      <CardHeader>
        <CardTitle>{name}</CardTitle>
        <CardDescription className="line-clamp-2">{description}</CardDescription>
      </CardHeader>
      <CardContent className="flex-grow">
        <p className="text-lg font-semibold">${price.toFixed(2)}</p>
      </CardContent>
      <CardFooter>
        <Button className="w-full" onClick={handleBuyClick}>
          Order Now
        </Button>
      </CardFooter>
    </Card>
  )
}
