"use client"

import Link from "next/link"
import { MountainIcon } from "lucide-react"
import { Button } from "@/components/ui/button"

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background">
      <div className="container flex h-16 items-center space-x-4 sm:justify-between sm:space-x-0">
        <div className="flex gap-6 md:gap-10">
          <Link href="/" className="flex items-center space-x-2">
            <MountainIcon className="h-6 w-6" />
            <span className="inline-block font-bold">Delicious Eats</span>
          </Link>
          <nav className="flex items-center space-x-4 text-sm font-medium">
            <Link href="/menu" className="hover:text-primary">
              Menu
            </Link>
            <Link href="/booking" className="hover:text-primary">
              Book a Table
            </Link>
          </nav>
        </div>
        <div className="flex flex-1 items-center justify-end space-x-4">
          <nav className="flex items-center space-x-1">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/booking">Reserve Now</Link>
            </Button>
          </nav>
        </div>
      </div>
    </header>
  )
}
