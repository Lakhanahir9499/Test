import Link from "next/link"
import { MountainIcon } from "lucide-react"

export function SiteFooter() {
  return (
    <footer className="border-t bg-background py-8">
      <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
        <div className="flex flex-col items-center gap-4 px-8 md:flex-row md:gap-2 md:px-0">
          <MountainIcon className="h-6 w-6" />
          <p className="text-center text-sm leading-loose md:text-left">
            &copy; {new Date().getFullYear()} Delicious Eats. All rights reserved.
          </p>
        </div>
        <nav className="flex gap-4 text-sm">
          <Link href="#" className="hover:underline">
            Privacy Policy
          </Link>
          <Link href="#" className="hover:underline">
            Terms of Service
          </Link>
        </nav>
      </div>
    </footer>
  )
}
