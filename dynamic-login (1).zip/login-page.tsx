"use client"

import type React from "react"
import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function Component() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Sign In attempt with:", { email, password })
    // Implement sign-in logic here
  }

  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault()
    if (password !== confirmPassword) {
      alert("Passwords do not match!")
      return
    }
    console.log("Sign Up attempt with:", { email, password })
    // Implement sign-up logic here
  }

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden p-4">
      {/* Animated Background */}
      <div className="absolute inset-0 z-0 animated-gradient-bg opacity-70" aria-hidden="true" />

      {/* Login/Signup Card Container with Entry Animation and Glassmorphism */}
      <motion.div
        initial={{ opacity: 0, y: 50, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        whileHover={{ scale: 1.01, boxShadow: "0 20px 40px rgba(0, 0, 0, 0.2)" }}
        className="z-10 w-full max-w-md rounded-xl shadow-2xl p-6
                   bg-white/20 dark:bg-gray-900/20 backdrop-blur-xl
                   border border-white/30 dark:border-gray-700/30
                   transition-all duration-300 ease-in-out"
      >
        <Card className="border-none shadow-none bg-transparent">
          <CardHeader className="text-center pb-6">
            <CardTitle className="text-3xl font-bold text-gray-900 dark:text-white">
              {/* Dynamic Title based on active tab */}
              <Tabs defaultValue="signin">
                <TabsList className="grid w-full grid-cols-2 mb-6 bg-white/30 dark:bg-gray-800/30 backdrop-blur-sm">
                  <TabsTrigger value="signin">Sign In</TabsTrigger>
                  <TabsTrigger value="signup">Sign Up</TabsTrigger>
                </TabsList>

                {/* Sign In Tab Content */}
                <TabsContent value="signin">
                  <CardTitle className="text-3xl font-bold text-gray-900 dark:text-white">Welcome Back!</CardTitle>
                  <CardDescription className="text-muted-foreground mt-2">
                    Sign in to your account to continue.
                  </CardDescription>
                </TabsContent>

                {/* Sign Up Tab Content */}
                <TabsContent value="signup">
                  <CardTitle className="text-3xl font-bold text-gray-900 dark:text-white">Join Us!</CardTitle>
                  <CardDescription className="text-muted-foreground mt-2">
                    Create your account to get started.
                  </CardDescription>
                </TabsContent>
              </Tabs>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="signin">
              <TabsList className="hidden" /> {/* Hide the TabsList here as it's in CardHeader */}
              {/* Sign In Tab Content */}
              <TabsContent value="signin">
                <form onSubmit={handleSignIn} className="space-y-6">
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2, duration: 0.4, ease: "easeOut" }}
                    className="space-y-2"
                  >
                    <Label htmlFor="signin-email" className="text-gray-800 dark:text-gray-200">
                      Email
                    </Label>
                    <Input
                      id="signin-email"
                      type="email"
                      placeholder="m@example.com"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="bg-white/50 dark:bg-gray-800/50 border-white/40 dark:border-gray-600/40 text-gray-900 dark:text-white placeholder:text-gray-600 dark:placeholder:text-gray-400"
                    />
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3, duration: 0.4, ease: "easeOut" }}
                    className="space-y-2"
                  >
                    <Label htmlFor="signin-password" className="text-gray-800 dark:text-gray-200">
                      Password
                    </Label>
                    <Input
                      id="signin-password"
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="bg-white/50 dark:bg-gray-800/50 border-white/40 dark:border-gray-600/40 text-gray-900 dark:text-white placeholder:text-gray-600 dark:placeholder:text-gray-400"
                    />
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4, duration: 0.4, ease: "easeOut" }}
                  >
                    <Button type="submit" className="w-full rgb-button-effect">
                      <span>Sign In</span>
                    </Button>
                  </motion.div>
                </form>
              </TabsContent>
              {/* Sign Up Tab Content */}
              <TabsContent value="signup">
                <form onSubmit={handleSignUp} className="space-y-6">
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2, duration: 0.4, ease: "easeOut" }}
                    className="space-y-2"
                  >
                    <Label htmlFor="signup-email" className="text-gray-800 dark:text-gray-200">
                      Email
                    </Label>
                    <Input
                      id="signup-email"
                      type="email"
                      placeholder="m@example.com"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="bg-white/50 dark:bg-gray-800/50 border-white/40 dark:border-gray-600/40 text-gray-900 dark:text-white placeholder:text-gray-600 dark:placeholder:text-gray-400"
                    />
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3, duration: 0.4, ease: "easeOut" }}
                    className="space-y-2"
                  >
                    <Label htmlFor="signup-password" className="text-gray-800 dark:text-gray-200">
                      Password
                    </Label>
                    <Input
                      id="signup-password"
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="bg-white/50 dark:bg-gray-800/50 border-white/40 dark:border-gray-600/40 text-gray-900 dark:text-white placeholder:text-gray-600 dark:placeholder:text-gray-400"
                    />
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.4, duration: 0.4, ease: "easeOut" }}
                    className="space-y-2"
                  >
                    <Label htmlFor="confirm-password" className="text-gray-800 dark:text-gray-200">
                      Confirm Password
                    </Label>
                    <Input
                      id="confirm-password"
                      type="password"
                      required
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="bg-white/50 dark:bg-gray-800/50 border-white/40 dark:border-gray-600/40 text-gray-900 dark:text-white placeholder:text-gray-600 dark:placeholder:text-gray-400"
                    />
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5, duration: 0.4, ease: "easeOut" }}
                  >
                    <Button type="submit" className="w-full rgb-button-effect">
                      <span>Sign Up</span>
                    </Button>
                  </motion.div>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
          <CardFooter className="text-center text-sm text-muted-foreground justify-center pt-6">
            {/* Dynamic Footer Text based on active tab */}
            <Tabs defaultValue="signin">
              <TabsList className="hidden" /> {/* Hide the TabsList here */}
              <TabsContent value="signin">
                Forgot your password?{" "}
                <a href="#" className="underline ml-1 text-blue-600 dark:text-blue-400">
                  Reset here
                </a>
              </TabsContent>
              <TabsContent value="signup">
                Already have an account?{" "}
                <a href="#" className="underline ml-1 text-blue-600 dark:text-blue-400">
                  Sign in
                </a>
              </TabsContent>
            </Tabs>
          </CardFooter>
        </Card>
      </motion.div>
    </div>
  )
}
